use piston::Key::R;

use crate::board::{
    bit_array::BitArray, bit_array_lookup::{
        BISHOP_BLOCKER_MASK, BISHOP_MOVE_TABLE, COLUMNS, FIRST_RANK_ATTACK, ROOK_BLOCKER_MASK, ROOK_MOVE_TABLE, ROWS,
    }, square::{self, Square},
};

use super::kogge_gen::{DIAGONAL_FILL_FUNCTIONS_CAP, ORTHOGONAL_FILL_FUNCTIONS_CAP};

//Move generation
pub fn gen_rook_moves(square: i8, allied: u64, opponent: u64) -> u64 {
    const DIRECTIONS: [(i8, i8); 4] = [(0, 1), (0, -1), (1, 0), (-1, 0)];

    let mut moves = 0;
    let x = square.file();
    let y = square.rank();
    for (dx, dy) in DIRECTIONS {
        let mut sx = x + dx;
        let mut sy = y + dy;

        while sx >= 0 && sx < 8 && sy >= 0 && sy < 8 {
            let next = square::from_file_rank(sx, sy);
            if opponent.get_bit(next) {
                moves.set_bit(next);
                break;
            } else if allied.get_bit(next) {
                break;
            } else {
                moves.set_bit(next);
            }

            sx += dx;
            sy += dy;
        }
    }

    return moves;
}

pub fn gen_bishop_moves(square: i8, allied: u64, opponent: u64) -> u64 {
    const DIRECTIONS: [(i8, i8); 4] = [(1, 1), (1, -1), (-1, 1), (-1, -1)];

    let mut moves = 0;
    let x = square.file() as i8;
    let y = square.rank() as i8;
    for (dx, dy) in DIRECTIONS {
        let mut sx = x + dx;
        let mut sy = y + dy;

        while sx >= 0 && sx < 8 && sy >= 0 && sy < 8 {
            let next = square::from_file_rank(sx, sy);
            if opponent.get_bit(next) {
                moves.set_bit(next);
                break;
            } else if allied.get_bit(next) {
                break;
            } else {
                moves.set_bit(next);
            }

            sx += dx;
            sy += dy;
        }
    }

    return moves;
}

pub fn gen_queen_moves(square: i8, allied: u64, opponent: u64) -> u64 {
    return gen_rook_moves(square, allied, opponent) | gen_bishop_moves(square, allied, opponent);
}

pub fn gen_queen_moves_kogge_occ(bb: u64, occupied: u64) -> u64 {
    gen_rook_moves_kogge_occ(bb, occupied) | gen_bishop_moves_kogge_occ(bb, occupied)
}

pub fn gen_rook_moves_pext(square: i8, occupied: u64) -> u64 {
    let index = order_bits(occupied, ROOK_BLOCKER_MASK[square as usize]);

    return ROOK_MOVE_TABLE[square as usize][index as usize];
}

pub fn gen_bishop_moves_pext(square: i8, occupied: u64) -> u64 {
    let index = order_bits(occupied, BISHOP_BLOCKER_MASK[square as usize]);

    return BISHOP_MOVE_TABLE[square as usize][index as usize];
}

pub fn gen_rook_moves_kindergarten(sq: i8, mut occ: u64) -> u64 {
    //https://chessprogramming.org/Kindergarten_Bitboards
    const A_FILE: u64 = COLUMNS[0];
    const H_FILE: u64 = COLUMNS[7];
    const DIA_A1H8: u64 = 0x8040201008040201;
    const DIA_C2H7: u64 = 0x0080402010080400;

    let row = (sq >> 3) as usize;
    let file = (sq & 7) as usize;
    let first_rank = (occ & ROWS[row]) >> (row << 3);
    let h_moves = (FIRST_RANK_ATTACK[((first_rank >> 1) & 63) as usize][file] as u64) << (row << 3);
    
    occ =  A_FILE  & (occ >> file);
    occ = (DIA_C2H7 *  occ) >> 58;
    occ =  DIA_A1H8 * FIRST_RANK_ATTACK[(occ & 63) as usize][((sq^56) >> 3) as usize] as u64;
    let vert_moves = (H_FILE  &  occ) >> (file^7);
    
    return vert_moves | h_moves;
}
//
pub fn gen_rook_moves_kindergarten_full(sq: i8, mut occ: u64) -> u64 {
    //https://chessprogramming.org/Kindergarten_Bitboards
    const A_FILE: u64 = COLUMNS[0];
    const DIA_C2H7: u64 = 0x0080402010080400;

    let row = (sq >> 3) as usize;
    let file = (sq & 7) as usize;
    let first_rank = (occ & ROWS[row]) >> (row << 3);
    let mut full_occ = (first_rank >> 1) & 63;

    occ =  A_FILE  & (occ >> file);
    occ = (DIA_C2H7 *  occ) >> 58;
    
    full_occ |= occ << 6;
    
    return ROOK_MOVE_TABLE[sq as usize][full_occ as usize & 2047];
}


pub fn order_bits(value: u64, mask: u64) -> u64 {
    return bitintr::Pext::pext(value, mask); //650 ms

    //return bitintr::Pdep::pdep(value, mask);
    // let mut ret = 0;
    // for i in iterate_set_bits(mask) {
    //     ret = (ret << 1) | (value >> i) & 1;
    // }

    // return ret; //650 ms

    // unsafe {
    //     return core::arch::x86_64::_pext_u64(value, mask); //990 ms
    // }
}

pub fn gen_rook_moves_kogge_occ(bb: u64, occupied: u64) -> u64 {
    let mut next = 0;
    let free = !occupied;

    for f in ORTHOGONAL_FILL_FUNCTIONS_CAP {
        next |= f(bb, free);
    }

    return next;
}
pub fn gen_rook_moves_kogge(bb: u64, allied: u64, opponent: u64) -> u64 {
    let mut next = 0;
    let free = !(allied | opponent);

    for f in ORTHOGONAL_FILL_FUNCTIONS_CAP {
        next |= f(bb, free);
    }

    return next & !allied;
}

pub fn gen_bishop_moves_kogge_occ(bb: u64, occupied: u64) -> u64 {
    let mut next = 0;
    let free = !occupied;

    for f in DIAGONAL_FILL_FUNCTIONS_CAP {
        next |= f(bb, free);
    }

    return next;
}
pub fn gen_bishop_moves_kogge(bb: u64, allied: u64, opponent: u64) -> u64 {
    let mut next = 0;
    let free = !(allied | opponent);

    for f in DIAGONAL_FILL_FUNCTIONS_CAP {
        next |= f(bb, free);
    }

    return next & !allied;
}

#[cfg(test)]
mod slider_gen_test {
    use rand::{rngs::StdRng, Rng};

    use crate::{board::{
        bit_array::BitArray,
        square::{self, Square, VALID_SQUARES},
    }, moves::slider_gen::gen_rook_moves_kindergarten};

    use super::{
        gen_bishop_moves, gen_bishop_moves_kogge, gen_bishop_moves_pext, gen_rook_moves,
        gen_rook_moves_kogge, gen_rook_moves_pext,
    };

    fn fill_board(rng: &mut StdRng) -> (u64, u64) {
        let mut allied = 0;
        let mut opponent = 0;

        for x in 0..8 {
            for y in 0..8 {
                let square = square::from_file_rank(x, y);
                if rng.gen_bool(0.1) {
                    allied.set_bit(square);
                } else if rng.gen_bool(0.1) {
                    opponent.set_bit(square);
                }
            }
        }

        return (allied, opponent);
    }

    #[test]
    fn all_slider_test() {
        let mut rng: rand::rngs::StdRng = rand::SeedableRng::seed_from_u64(0);

        for _ in 0..1000 {
            let (allied, opponent) = fill_board(&mut rng);

            for s in VALID_SQUARES {
                let allied = allied | s.bit_array();

                let m1 = gen_bishop_moves(s, allied, opponent);
                let m2 = gen_bishop_moves_pext(s, allied | opponent) & !allied;
                let m3 = gen_bishop_moves_kogge(s.bit_array(), allied, opponent);

                if m1 != m2 || m1 != m3 {
                    println!("Allied:");
                    allied.print();
                    println!("Opponent:");
                    opponent.print();
                    println!("i8: {}", s.to_string());
                    println!("gen_moves:");
                    m1.print();
                    println!("gen_moves_pext:");
                    m2.print();
                    println!("gen_moves_kogge:");
                    m3.print();
                    panic!();
                }

                let m1 = gen_rook_moves(s, allied, opponent);
                let m2 = gen_rook_moves_pext(s, allied | opponent) & !allied;
                let m3 = gen_rook_moves_kogge(s.bit_array(), allied, opponent);
                let m4 = gen_rook_moves_kindergarten(s, allied | opponent) & !allied;

                if m1 != m2 || m1 != m3 || m1 != m4 {
                    println!("Allied:");
                    allied.print();
                    println!("Opponent:");
                    opponent.print();
                    println!("i8: {}", s.to_string());
                    println!("gen_moves:");
                    m1.print();
                    // println!("gen_moves_pext:");
                    // m2.print();
                    // println!("gen_moves_kogge:");
                    // m3.print();
                    println!("gen_moves_kindergarten:");
                    m4.print();
                    panic!();
                }
            }
        }
    }
}
